import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class addRecord {
    private static final DateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

    public static void add() throws IOException {
    int count = Counter.getCount();

    PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter("bpDetail.txt", true)));

    Date date = new Date();
                    System.out.println(sdf.format(date));

                    System.out.println("Enter Sys: ");
    Scanner s = new Scanner(System.in);
    int sys = s.nextInt();

                    System.out.println("Enter Dia: ");
    int dia = s.nextInt();

                    System.out.println("Enter Pulse: ");
    int pulse = s.nextInt();

                    pw.println("[ Record : " + count++ + "]\n" + date + "\nSys: " + sys + "\nDia: " + dia
                            + "\nPulse: " + pulse + "\n");

                    Counter.putCount(count);
                    pw.close();
    }

}
