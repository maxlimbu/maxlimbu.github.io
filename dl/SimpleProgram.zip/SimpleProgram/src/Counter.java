import java.io.*;

public class Counter {
    public static int getCount() {

       int count = 0;
        try {
            if ( !new File("myCount.txt").exists())
                return 1;
            else {
                BufferedReader br = new BufferedReader(new FileReader(new File("myCount.txt")));
                String s = br.readLine();
                count = Integer.parseInt(s);
                br.close();
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
        return count;
    }

    public static void putCount(int count) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(new File("myCount.txt")));
            bw.write(Integer.toString(count));
            bw.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

}
