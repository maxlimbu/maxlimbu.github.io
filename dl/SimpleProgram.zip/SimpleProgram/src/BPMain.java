
import java.io.IOException;
import java.util.Scanner;


public class BPMain {

    //private static final AtomicInteger count = new AtomicInteger(0);
    //static int count = 0;


    public static void main(String[] args) throws IOException {

        Scanner input = new Scanner(System.in);
        boolean mainLoop = true;

        int choice;
        while(true) {

            System.out.println("++++++++++++++++");
            System.out.println("+ BP Main Menu +");
            System.out.println("++++++++++++++++");
            System.out.print("\n1.) Add a record \n");
            System.out.print("2.) Print All Record.\n");
            System.out.print("3.) Exit\n");
            System.out.print("\nEnter Your Menu Choice: ");

            choice = input.nextInt();


            switch (choice) {

                case 1:
        addRecord.add();
             break;


                case 2:
                    printAll.print();
                    break;


                case 3:
                    System.out.println("Exiting.....");
                   System.exit(0);
                   break;

                   default :
                    System.out.println("\nThis is not a valid Menu Option! Please Select Another");
                    break;

            }
        }
        //System.out.println(count);

    }
}

