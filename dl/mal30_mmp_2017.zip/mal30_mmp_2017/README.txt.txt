
ANDROID TOUCH SCREEN GAME
CONNECT 5 IN A ROW
Max Limbu(mal30)
------ For Windows and Mac version thew window needs to be resized but grid buttons appear weirdly-------

There are four folders :
 
mal30_mmp_2017_unity_project - contains the code and unity files that was needed in order to build the game and can be ran on Unity
Unity_project = contains newboardgamefile which has assets
assets contains: Scene, Script and any relevant file that is need to create the game overall if using Unity the whole newgameboard 
be opened as a project. 

mal30_mmp_2017_desktop_version - contains the exe file to run the game on desktop version

mal30_mmp_2017_android_version- contains the apk file to install and run the game on android

mal30_mmp_2017_mac_version- contains the app file to run the game on mac

THINGS WORKING:- Main Menu: Play button, Continue(Loads saved game) , Help(Loads Help Scene), Quit(Quits game) 
                 Board Size: 5x5, 6x6, 7x7
		 Easy AI- places the piece randomly 
                 Player vs Player - Two human players can play
                 Player vs AI - Player plays with AI(Easy)
                 Game: Player turn, Winning algorithm(5 in a row), Winner, Draw, Save
                 Player Colour: Player 1: Blue
                             Player 2/AI: Green

-THINGS NOT WORKING: 
-Advanced AI algorithm from the AI selection menu, if ran it breaks the game or Unity Editor
 if it is being used.
-When a player wins and saves the game, if board is not full player can still play when they load
(but wouldn't make sense to save or load a finished game)











